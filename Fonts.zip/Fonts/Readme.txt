These font files are not required for the operation of Plugin Oberon, that's
why they are compressed. However, you may install these fonts to improve the
text rendering speed by Windows, see readme.txt in the root folder.
Alexander Iljin, 25.11.2010.
